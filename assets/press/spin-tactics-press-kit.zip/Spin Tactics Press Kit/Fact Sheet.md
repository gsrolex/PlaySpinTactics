# Spin Tactics: Press Kit

## Fact sheet

| | |
|---|---|
| **Title** | Spin Tactics |
| **Developer** | Dead Broke Games (solo developer) |
| **Publisher** | Self-published |
| **Release date** | November 12, 2026 |
| **Platforms** | Windows and macOS, on Steam |
| **Price** | $14.99 USD, with Steam regional pricing |
| **Free demo** | Yes, available now on Steam |
| **Genre** | Roguelike strategy, engine-builder |
| **Run length** | 30 to 60 minutes |
| **Languages** | English, French, German, Spanish, Italian, Portuguese (Brazil), Polish, Russian, Ukrainian, Turkish, Japanese, Korean, Simplified Chinese, Traditional Chinese |
| **Steam** | https://store.steampowered.com/app/3856990 |
| **Website** | https://playspintactics.com/ |
| **Press page** | https://playspintactics.com/press/ |
| **Press contact** | spintactics2d@gmail.com |
| **X / Twitter** | https://x.com/PlaySpinTactics |
| **Discord** | https://discord.gg/7kXTGyWjWc |
| **YouTube** | https://www.youtube.com/channel/UC9TVGazYX4suPV6o6mBnn6w |
| **TikTok** | https://www.tiktok.com/@spin.tactics |
| **Instagram** | https://www.instagram.com/spin.tactics |
| **IndieDB** | https://www.indiedb.com/games/spin-tactics |

## Short description

A roguelike strategy game about building an engine. Pick your Companions and the order they fire in, change your symbols with Gems, and spend each Action on a spin or a swap. The reels hand you the pieces; the plan is yours. Set inside a slot machine, with no real-money gambling.

## Long description

Spin Tactics is a roguelike strategy game about building an engine. It's set inside a slot machine, but it plays like a strategy game: every encounter gives you a score goal and a few Actions, the reels hand you the symbols, and what you do with them is up to you.

You equip eight Companions from more than 90, and they fire in slot order, left to right. Many of them boost the Companion next to them, so where you put them matters. Gems change a symbol for the rest of the run: its colour, when it scores, how much it scores, or turn it into a copy of another. Every spin and every swap costs an Action. Spin for a fresh board, or swap to finish the combo in front of you.

A run is eight encounters. Connect three or more symbols of one colour for a combo, from SMALL to GALACTIC, sell what you don't need into the Black Hole, and beat the bosses that push back. Between runs you unlock new Companions from Discovery Packs and build the Portal you start with from Chips. Beat the game and Ascension makes every boss ask for more.

**No real-money gambling. No microtransactions.**

## Features

- **90+ Companions, eight slots.** You decide the order they fire in, and many boost their neighbour.
- **Gems that last the whole run.** Change a symbol's colour, its timing or how much it scores, or copy it onto another.
- **Spin or swap.** A few Actions each round: spin for a fresh board or swap to finish the combo in front of you.
- **Bosses that push back.** Some drain your score, others take away your spins.
- **The Black Hole.** Sell any Companion, symbol or Gem you don't need.
- **Between runs.** Unlock Companions from Discovery Packs and build the Portal you start with from Chips.
- **Ascension and leaderboards.** 30 to 60 minute runs, and every run counts on the online leaderboard.

## About the developer

Hi, I'm Ammon, and Dead Broke Games is just me. I've been making Spin Tactics on my own for almost two years, mostly in the evenings and late at night. I always liked the feeling of a slot machine, but I wanted to be the one making the decisions, so I made the game I wanted to play. I'm really proud of how it turned out, and I hope you enjoy it.

## In this kit

- `screenshots/`: 8 gameplay screenshots, 1920×1080
- `bosses/`: 10 boss portraits, transparent PNG
- `companions/`: 12 Companion cards in all four rarities, transparent PNG
- `key-art/`: Steam capsules and the library hero
- `logos/`: logo in neon, white, on black, round, and the app icon

Streaming and videos are welcome, monetised ones too. No need to ask; a link to the Steam page is always appreciated.
